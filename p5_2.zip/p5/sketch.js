var graphic;

function setup() {
  createCanvas(800, 800);
  graphic = loadImage("cole.png")
  graphic2 = loadImage("cole2.png")

}
function draw() {

for (var countRows = 0; countRows < 10; countRows++) {
  image(graphic2, mouseX, mouseY);
  image(graphic, 0, 0);
  rotate(random(1,90))
  scale(random(0.1,1.5))
  translate(random(0,600),random(0,600))
}

}
